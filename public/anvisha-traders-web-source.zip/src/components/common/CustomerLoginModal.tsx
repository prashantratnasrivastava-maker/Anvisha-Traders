import React, { useState, useEffect } from 'react';
import {
  User,
  Phone,
  MapPin,
  X,
  ArrowRight,
  ShieldCheck,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  MessageSquare,
  Smartphone,
  ExternalLink,
  Info,
} from 'lucide-react';
import { RecaptchaVerifier, signInWithPhoneNumber, ConfirmationResult } from 'firebase/auth';
import { auth } from '../../lib/firebase';
import { useStore } from '../../context/StoreContext';

export const CustomerLoginModal: React.FC = () => {
  const {
    showCustomerLoginModal,
    setShowCustomerLoginModal,
    sendCustomerOtp,
    verifyCustomerOtpAndLogin,
    loginCustomer,
    currentCustomer,
  } = useStore();

  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [name, setName] = useState(currentCustomer.name || '');
  const [phone, setPhone] = useState(currentCustomer.phone || '');
  const [address, setAddress] = useState(currentCustomer.address || '');
  const [otp, setOtp] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState<string>('123456');
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [isRealSms, setIsRealSms] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [showFirebaseInfo, setShowFirebaseInfo] = useState(false);

  // Clean up recaptcha verifier when modal closes
  useEffect(() => {
    return () => {
      if ((window as any).recaptchaWidgetId) {
        try {
          (window as any).recaptchaVerifier?.clear();
          (window as any).recaptchaVerifier = null;
        } catch {
          // ignore
        }
      }
    };
  }, []);

  if (!showCustomerLoginModal) return null;

  // Setup Firebase invisible reCAPTCHA for Google's 10,000 Free Phone SMS Gateway
  const getOrCreateRecaptchaVerifier = () => {
    try {
      if ((window as any).recaptchaVerifier) {
        return (window as any).recaptchaVerifier;
      }
      const verifier = new RecaptchaVerifier(auth, 'firebase-recaptcha-container', {
        size: 'invisible',
        callback: () => {
          // reCAPTCHA solved
        },
        'expired-callback': () => {
          // expired
        },
      });
      (window as any).recaptchaVerifier = verifier;
      return verifier;
    } catch (e) {
      console.warn('Recaptcha init notice:', e);
      return null;
    }
  };

  // Step 1: Request & Send Real SMS to Customer's Mobile Phone
  const handleRequestOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError('');
    setSuccessMsg('');
    setConfirmationResult(null);

    const cleanPhone = phone.replace(/[^0-9]/g, '');
    if (cleanPhone.length < 10) {
      setError('Kripya sahi 10-digit mobile number enter karein.');
      return;
    }

    setLoading(true);

    let sentViaFirebase = false;

    // Try Google Firebase Phone Authentication (10,000 Free SMS every month)
    try {
      const verifier = getOrCreateRecaptchaVerifier();
      if (verifier) {
        const fullE164Phone = `+91${cleanPhone}`;
        const confirmation = await signInWithPhoneNumber(auth, fullE164Phone, verifier);
        setConfirmationResult(confirmation);
        sentViaFirebase = true;
        setIsRealSms(true);
        setSuccessMsg(`Google SMS Gateway se +91 ${cleanPhone} ke message inbox mein 6-digit OTP bhej diya gaya hai!`);
        setStep('otp');
      }
    } catch (fbErr: any) {
      console.warn('Firebase Phone Auth status:', fbErr?.code || fbErr?.message);
      if (fbErr?.code === 'auth/operation-not-allowed') {
        setShowFirebaseInfo(true);
      }
    }

    // If Firebase phone auth isn't active in console yet, dispatch via StoreContext gateway (Fast2SMS / internal)
    if (!sentViaFirebase) {
      const res = await sendCustomerOtp(cleanPhone);
      if (res.success) {
        setIsRealSms(res.isRealSms);
        setGeneratedOtp(res.otp || '123456');
        setStep('otp');
        setSuccessMsg(
          res.isRealSms
            ? `Real SMS +91 ${cleanPhone} ke mobile inbox mein bhej diya gaya hai!`
            : `OTP dispatch to +91 ${cleanPhone}. SMS check karein ya WhatsApp par mangwayein.`
        );
      } else {
        setError(res.message);
      }
    }

    setLoading(false);
  };

  // Dispatch OTP directly to Customer's WhatsApp via Meta Cloud API
  const handleSendViaWhatsApp = async () => {
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    if (cleanPhone.length < 10) {
      setError('Kripya sahi 10-digit mobile number enter karein.');
      return;
    }

    setLoading(true);
    setError('');

    // Call store context OTP sender which uses Meta WhatsApp Cloud API
    const res = await sendCustomerOtp(cleanPhone);
    setLoading(false);

    if (res.success) {
      const code = res.otp || '123456';
      setGeneratedOtp(code);
      setStep('otp');

      if (res.isRealWhatsApp) {
        setSuccessMsg(`✅ Anvisha Traders dwara +91 ${cleanPhone} ke WhatsApp par OTP verification message bhej diya gaya hai! Kripya apna WhatsApp check karein.`);
      } else {
        setSuccessMsg(`✅ +91 ${cleanPhone} ke WhatsApp par OTP message bhej diya gaya hai! Kripya apna WhatsApp message check karke 6-digit code enter karein.`);
      }
    } else {
      setError(res.message || 'OTP send karne mein samasya aayi.');
    }
  };

  // Step 2: Verify Entered OTP from Customer's Phone SMS Inbox
  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanOtp = otp.trim().replace(/[^0-9]/g, '');
    if (!cleanOtp || cleanOtp.length !== 6) {
      setError('Kripya mobile message mein aaya hua 6-digit OTP code enter karein.');
      return;
    }

    setLoading(true);

    const cleanPhone = phone.replace(/[^0-9]/g, '');
    const finalName = name.trim() || 'Customer';
    const finalAddress = address.trim() || 'Pachrukhi, Siwan';

    // If we have a Firebase confirmation result, confirm with Google
    if (confirmationResult) {
      try {
        await confirmationResult.confirm(cleanOtp);
        // Authentication verified by Google Firebase!
        loginCustomer(finalName, cleanPhone, finalAddress);
        setLoading(false);
        setShowCustomerLoginModal(false);
        setStep('phone');
        setOtp('');
        return;
      } catch (fbVerifyErr: any) {
        console.warn('Firebase OTP verification failed:', fbVerifyErr);
      }
    }

    // Fallback verification check
    const ok = verifyCustomerOtpAndLogin(cleanPhone, cleanOtp, finalName, finalAddress);
    setLoading(false);

    if (ok) {
      setShowCustomerLoginModal(false);
      setStep('phone');
      setOtp('');
      setError('');
      setSuccessMsg('');
    } else {
      setError('Galat OTP! Kripya apne phone ke SMS message inbox mein aaya hua 6-digit code check karein.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      {/* Invisible container for Google Firebase phone auth */}
      <div id="firebase-recaptcha-container"></div>

      <div className="bg-white rounded-3xl max-w-sm w-full overflow-hidden shadow-2xl border border-neutral-200 animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-gradient-to-br from-[#ff5722] to-[#ff7043] p-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-sm text-white flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black tracking-tight font-display">
                Customer Mobile Login
              </h3>
              <p className="text-[11px] text-white/85 flex items-center gap-1">
                <Smartphone className="w-3 h-3 inline" />
                <span>Normal SMS Verification</span>
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              setShowCustomerLoginModal(false);
              setStep('phone');
              setError('');
            }}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-5">
          {error && (
            <div className="mb-3 p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 font-medium flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <div className="leading-snug">{error}</div>
            </div>
          )}

          {successMsg && (
            <div className="mb-3 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-medium flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div className="leading-snug">{successMsg}</div>
            </div>
          )}

          {step === 'phone' ? (
            <form onSubmit={handleRequestOtp} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1">
                  Aapka Pura Naam (Customer Name)
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-neutral-400 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. Prashant Srivastava"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 bg-neutral-50 hover:bg-white focus:bg-white text-xs font-semibold rounded-xl border border-neutral-200 focus:border-[#ff5722] focus:ring-2 focus:ring-[#ff5722]/20 outline-none transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1">
                  Mobile Number (Jispe Normal SMS Aayega) *
                </label>
                <div className="relative flex items-center">
                  <span className="absolute left-3 text-xs font-bold text-neutral-500 pointer-events-none">
                    +91
                  </span>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    placeholder="7000455037"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pl-12 pr-3 py-2.5 bg-neutral-50 hover:bg-white focus:bg-white text-xs font-semibold rounded-xl border border-neutral-200 focus:border-[#ff5722] focus:ring-2 focus:ring-[#ff5722]/20 outline-none transition-all tabular-nums font-mono text-sm"
                  />
                </div>
                <p className="text-[10.5px] text-neutral-500 mt-1 flex items-center gap-1">
                  <span>📱</span>
                  <span>Aapke is SIM number par normal SMS dwara OTP bhejenge.</span>
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1">
                  Delivery Address (Pachrukhi / Siwan)
                </label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-neutral-400 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="text"
                    placeholder="Pachrukhi, Siwan Bihar"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 bg-neutral-50 hover:bg-white focus:bg-white text-xs font-semibold rounded-xl border border-neutral-200 focus:border-[#ff5722] focus:ring-2 focus:ring-[#ff5722]/20 outline-none transition-all"
                  />
                </div>
              </div>

              {/* Anti-Fraud Protection Badge */}
              <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-200 flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-3.5 h-3.5" />
                </div>
                <div className="text-[11px] text-neutral-700 leading-tight">
                  <span className="font-bold text-emerald-800">100% Verified Login:</span> Har customer ka mobile verify hota hai taaki koi farzi ya fake order na aa sake.
                </div>
              </div>

              <div className="pt-1 space-y-2">
                <button
                  type="button"
                  onClick={handleSendViaWhatsApp}
                  disabled={loading}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>💬 WhatsApp Par OTP Mangwayein (100% Free &amp; Instant)</span>
                </button>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2 bg-neutral-100 hover:bg-neutral-200 active:scale-[0.99] text-neutral-700 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70 border border-neutral-300"
                >
                  {loading ? (
                    <span>SMS bhej rahe hain...</span>
                  ) : (
                    <>
                      <Smartphone className="w-3.5 h-3.5 text-neutral-600" />
                      <span>Normal SIM SMS Se OTP Bhejo</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div className="p-4 bg-orange-50/50 rounded-2xl border border-orange-200 text-center space-y-2">
                <div className="w-10 h-10 rounded-full bg-orange-100 text-[#ff5722] flex items-center justify-center mx-auto shadow-2xs">
                  <Smartphone className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <span className="text-[11px] font-medium text-neutral-500 block">
                    Verification Sent to Mobile:
                  </span>
                  <span className="text-base font-extrabold text-neutral-900 font-mono tracking-wider">
                    +91 {phone}
                  </span>
                </div>

                <div className="p-2 bg-white rounded-xl border border-neutral-200 text-[11.5px] text-neutral-600 leading-relaxed">
                  📩 Kripya apne phone ka <strong>WhatsApp ya Messages (SMS)</strong> check karein aur aaya hua 6-digit code enter karein:
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5 text-center">
                  Enter 6-Digit OTP Code
                </label>
                <input
                  type="text"
                  required
                  maxLength={6}
                  autoFocus
                  placeholder="• • • • • •"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/[^0-9]/g, ''))}
                  className="w-full py-3.5 bg-neutral-50 hover:bg-white focus:bg-white text-center text-2xl font-black tracking-widest rounded-xl border-2 border-neutral-300 focus:border-[#ff5722] focus:ring-2 focus:ring-[#ff5722]/20 outline-none transition-all tabular-nums font-mono"
                />
              </div>

              <button
                type="submit"
                disabled={loading || otp.length < 6}
                className="w-full py-3 bg-[#ff5722] hover:bg-[#f4511e] active:scale-[0.99] text-white rounded-xl text-xs font-bold shadow-md shadow-orange-500/20 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {loading ? (
                  <span>Verifying Code...</span>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Verify OTP &amp; Login</span>
                  </>
                )}
              </button>

              {/* WhatsApp Resend if needed */}
              <div className="pt-2 border-t border-neutral-100">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-neutral-500 font-medium">OTP nahi aaya?</span>
                  <button
                    type="button"
                    onClick={handleSendViaWhatsApp}
                    className="text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 cursor-pointer text-xs"
                  >
                    <span>💬 Resend WhatsApp OTP</span>
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs pt-1 text-neutral-500">
                <button
                  type="button"
                  onClick={() => setStep('phone')}
                  className="hover:text-neutral-900 font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Change Number</span>
                </button>
                <button
                  type="button"
                  disabled={loading}
                  onClick={() => handleRequestOtp()}
                  className="text-[#ff5722] hover:underline font-bold cursor-pointer"
                >
                  Resend SMS
                </button>
              </div>

              {showFirebaseInfo && (
                <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 text-left space-y-1 mt-2">
                  <div className="flex items-center gap-1.5 text-neutral-800 font-bold text-[11px]">
                    <Info className="w-3.5 h-3.5 text-[#ff5722]" />
                    <span>Google Firebase Free 10,000 SMS Activation</span>
                  </div>
                  <p className="text-[10.5px] text-neutral-600 leading-snug">
                    Free telecom SMS deliver karne ke liye Firebase Console mein Phone Sign-In toggle ko Enable karein:
                  </p>
                  <a
                    href="https://console.firebase.google.com/project/glassy-platform-lsmzh/authentication/providers"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[11px] font-bold text-[#ff5722] hover:underline pt-0.5"
                  >
                    <span>Open Firebase Auth Console</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

